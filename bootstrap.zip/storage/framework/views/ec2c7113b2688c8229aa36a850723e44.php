<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Factura #<?php echo e($factura->id); ?></title>
    <style>
        body { font-family: sans-serif; font-size: 14px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #ccc; padding: 5px; text-align: left; }
        h1 { font-size: 20px; margin-bottom: 0; }
    </style>
</head>
<body>
    <h1>Factura #<?php echo e($factura->id); ?></h1>
    <p><strong>Cliente:</strong> <?php echo e($factura->cliente->nombre); ?></p>
    <p><strong>Total:</strong> $<?php echo e(number_format($factura->total, 2)); ?></p>
    <p><strong>Estado:</strong> <?php echo e($factura->anulada ? 'Anulada' : 'Válida'); ?></p>

    <h3>Detalles:</h3>
    <table>
        <thead>
            <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>P. Unitario</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $factura->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($detalle->producto->nombre); ?></td>
                    <td><?php echo e($detalle->cantidad); ?></td>
                    <td>$<?php echo e(number_format($detalle->precio_unitario, 2)); ?></td>
                    <td>$<?php echo e(number_format($detalle->subtotal, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\William\Documents\UniversidadNP\Desarollo de Software Seguro\Parcial 2\Proyecto 2\sistema-facturacion-segura\resources\views/facturas/pdf.blade.php ENDPATH**/ ?>