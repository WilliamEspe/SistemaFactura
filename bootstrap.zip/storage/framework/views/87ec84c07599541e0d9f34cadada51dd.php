<?php $__env->startComponent('mail::message'); ?>
# Factura #<?php echo new \Illuminate\Support\EncodedHtmlString($factura->id); ?>


**Cliente:** <?php echo new \Illuminate\Support\EncodedHtmlString($factura->cliente->nombre); ?>  
**Total:** $<?php echo new \Illuminate\Support\EncodedHtmlString(number_format($factura->total, 2)); ?>  
**Estado:** <?php echo new \Illuminate\Support\EncodedHtmlString($factura->anulada ? 'Anulada' : 'Válida'); ?>


<?php $__env->startComponent('mail::button', ['url' => route('facturas.index')]); ?>
Ver Facturas
<?php echo $__env->renderComponent(); ?>

Gracias por su compra.  
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\William\Documents\UniversidadNP\Desarollo de Software Seguro\Parcial 2\Proyecto 2\sistema-facturacion-segura\resources\views/emails/factura.blade.php ENDPATH**/ ?>