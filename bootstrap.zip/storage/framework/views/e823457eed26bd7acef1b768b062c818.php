<?php echo e($slot); ?>

<?php /**PATH C:\Users\William\Documents\UniversidadNP\Desarollo de Software Seguro\Parcial 2\Proyecto 2\sistema-facturacion-segura\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>