

<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mt-8">

        <div class="flex justify-between items-center mb-6">
            <div class="flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-blue-600 mr-3" viewBox="0 0 20 20" fill="currentColor">
                <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
            </svg>
            <h2 class="text-3xl font-semibold text-gray-800">Gestión de Usuarios</h2>
            </div>
            <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg transition duration-300 shadow-md">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                <path fill-rule="evenodd" d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z" clip-rule="evenodd" />
            </svg>
            Regresar al Dashboard
            </a>
        </div>

        <!-- Búsqueda -->
        <div class="mb-6">
            <form action="<?php echo e(route('usuarios.index')); ?>" method="GET" class="flex">
            <div class="relative flex-1">
                <div class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <svg class="w-4 h-4 text-gray-500 transition-colors duration-200 hover:text-blue-600" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
                </svg>
                </div>
                <input type="search" name="search" id="search" class="block w-full p-2 pl-10 text-sm border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500" placeholder="Buscar usuarios..." value="<?php echo e(request('search')); ?>">
            </div>
            <button type="submit" class="px-4 py-2 ml-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:ring-4 focus:outline-none focus:ring-blue-300">
                Buscar
            </button>
            <?php if(request('search')): ?>
                <a href="<?php echo e(route('usuarios.index')); ?>" class="px-4 py-2 ml-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300">
                Limpiar
                </a>
            <?php endif; ?>
            </form>
        </div>

        <!-- Botón para abrir modal de crear -->
        <button onclick="openModal('crearModal')" class="bg-blue-500 text-white px-4 py-2 rounded mb-4">
            Nuevo Usuario
        </button>

        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 p-2 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
            <table class="w-full table-auto">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-4 py-2 text-left">Nombre</th>
                        <th class="px-4 py-2 text-left">Email</th>
                        <th class="px-4 py-2 text-left">Roles</th>
                        <th class="px-4 py-2 text-left">Estado</th>
                        <th class="px-4 py-2 text-left">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b">
                            <td class="px-4 py-2"><?php echo e($usuario->name); ?></td>
                            <td class="px-4 py-2"><?php echo e($usuario->email); ?></td>
                            <td class="px-4 py-2">
                                <form method="POST" action="<?php echo e(route('usuarios.asignarRol', $usuario)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <select name="roles[]" multiple class="border rounded px-2 py-1 w-full">
                                        <?php $__currentLoopData = \App\Models\Role::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($rol->id); ?>" <?php if($usuario->roles->contains($rol)): ?> selected <?php endif; ?>>
                                                <?php echo e($rol->nombre); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="submit"
                                        class="mt-2 bg-green-500 text-white px-2 py-1 rounded">Actualizar</button>
                                </form>
                            </td>
                            <td class="px-4 py-2">
                                <?php if($usuario->activo): ?>
                                    <span class="text-green-600 font-semibold">Activo</span>
                                <?php else: ?>
                                    <span class="text-red-600 font-semibold">Inactivo</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-2">

                                <button onclick="openModal('editarModal-<?php echo e($usuario->id); ?>')"
                                    class="text-blue-600 hover:underline">Editar</button>


                                <button onclick="openModal('eliminarPapelera-<?php echo e($usuario->id); ?>')"
                                    class="text-red-600 ml-2">Eliminar</button>


                                <?php if($usuario->activo): ?>

                                    <button onclick="openModal('inactivarModal-<?php echo e($usuario->id); ?>')"
                                        class="text-yellow-600 hover:underline ml-2">
                                        Inactivar
                                    </button>
                                <?php else: ?>

                                    <form method="POST" action="<?php echo e(route('usuarios.toggleEstado', $usuario)); ?>" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="text-green-600 hover:underline ml-2">
                                            Activar
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </td>

                        </tr>

                        <!-- Modal Editar -->
                        <div id="editarModal-<?php echo e($usuario->id); ?>"
                            class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
                            <div class="bg-white p-6 rounded shadow-md w-96">
                                <h3 class="text-lg font-bold mb-4">Editar Usuario</h3>
                                <form method="POST" action="<?php echo e(route('usuarios.update', $usuario)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                    <input type="text" name="name" value="<?php echo e($usuario->name); ?>"
                                        class="w-full mb-2 px-2 py-1 border rounded">
                                    <input type="email" name="email" value="<?php echo e($usuario->email); ?>"
                                        class="w-full mb-2 px-2 py-1 border rounded">
                                    <div class="flex justify-end">
                                        <button type="button" onclick="closeModal('editarModal-<?php echo e($usuario->id); ?>')"
                                            class="mr-2 px-4 py-1">Cancelar</button>
                                        <button type="submit"
                                            class="bg-green-600 text-white px-4 py-1 rounded">Actualizar</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <!-- Modal Eliminar -->
                        <div id="eliminarModal-<?php echo e($usuario->id); ?>"
                            class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
                            <div class="bg-white p-6 rounded shadow-md w-96">
                                <h3 class="text-lg font-bold mb-4">¿Eliminar Usuario?</h3>
                                <p>Esta acción no se puede deshacer.</p>
                                <form method="POST" action="<?php echo e(route('usuarios.destroy', $usuario)); ?>" class="mt-4">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <div class="flex justify-end">
                                        <button type="button" onclick="closeModal('eliminarModal-<?php echo e($usuario->id); ?>')"
                                            class="mr-2 px-4 py-1">Cancelar</button>
                                        <button type="submit" class="bg-red-600 text-white px-4 py-1 rounded">Eliminar</button>
                                    </div>
                                </form>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Crear -->
    <div id="crearModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
        <div class="bg-white p-6 rounded shadow-md w-96">
            <h3 class="text-lg font-bold mb-4">Nuevo Usuario</h3>
            <form method="POST" action="<?php echo e(route('usuarios.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="name" placeholder="Nombre" class="w-full mb-2 px-2 py-1 border rounded">
                <input type="email" name="email" placeholder="Correo" class="w-full mb-2 px-2 py-1 border rounded">
                <input type="password" name="password" placeholder="Contraseña"
                    class="w-full mb-2 px-2 py-1 border rounded">
                <div class="flex justify-end">
                    <button type="button" onclick="closeModal('crearModal')" class="mr-2 px-4 py-1">Cancelar</button>
                    <button type="submit" class="bg-blue-600 text-white px-4 py-1 rounded">Guardar</button>
                </div>
            </form>
        </div>
    </div>
    <!-- Modal Inactivar Usuario -->
    <div id="inactivarModal-<?php echo e($usuario->id); ?>"
        class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
        <div class="bg-white p-6 rounded shadow-md w-96">
            <h3 class="text-lg font-bold mb-4">Inactivar Usuario</h3>
            <form method="POST" action="<?php echo e(route('usuarios.inactivar', $usuario)); ?>">
                <?php echo csrf_field(); ?>
                <label class="block mb-2 text-sm font-medium text-gray-700">Motivo del bloqueo</label>
                <textarea name="motivo_bloqueo" class="w-full border rounded px-2 py-1 mb-4" rows="3" required
                    placeholder="Escribe el motivo aquí..."></textarea>
                <div class="flex justify-end">
                    <button type="button" onclick="closeModal('inactivarModal-<?php echo e($usuario->id); ?>')"
                        class="mr-2 px-4 py-1">Cancelar</button>
                    <button type="submit" class="bg-yellow-600 text-white px-4 py-1 rounded">Confirmar</button>
                </div>
            </form>
        </div>
    </div>
    <!-- Modal Eliminar Papelera -->
    <div id="eliminarPapelera-<?php echo e($usuario->id); ?>"
        class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
        <div class="bg-white p-6 rounded shadow-md w-96">
            <h3 class="text-lg font-bold mb-4">Eliminar Usuario</h3>
            <form method="POST" action="<?php echo e(route('usuarios.eliminar', $usuario)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>

                <label class="block mb-2">Motivo:</label>
                <textarea name="motivo_eliminacion" required class="w-full p-2 border rounded mb-2" rows="3"></textarea>

                <label class="block mb-2">
                    <input type="checkbox" name="confirmacion" required class="mr-2"
                        onchange="document.getElementById('btnEliminar<?php echo e($usuario->id); ?>').disabled = !this.checked">
                    Confirmo que deseo eliminar este usuario.
                </label>

                <div class="flex justify-end mt-4">
                    <button type="button" onclick="closeModal('eliminarPapelera-<?php echo e($usuario->id); ?>')"
                        class="px-4 py-2 mr-2">Cancelar</button>
                    <button type="submit" id="btnEliminar<?php echo e($usuario->id); ?>" class="bg-red-600 text-white px-4 py-2 rounded"
                        disabled>Eliminar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Scripts para abrir y cerrar modales -->
    <script>
        function openModal(id) {
            document.getElementById(id).classList.remove('hidden');
        }

        function closeModal(id) {
            document.getElementById(id).classList.add('hidden');
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\William\Documents\UniversidadNP\Desarollo de Software Seguro\Parcial 2\Proyecto 2\sistema-facturacion-segura\resources\views/usuarios/index.blade.php ENDPATH**/ ?>