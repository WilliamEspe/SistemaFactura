

<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 mt-8">
        <h2 class="text-2xl font-bold mb-4">Listado de Facturas</h2>
        <div class="flex justify-between items-center mb-4">
            <a href="<?php echo e(route('dashboard')); ?>" class="bg-gray-500 hover:bg-gray-600 text-white py-2 px-4 rounded flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd" d="M9.707 14.707a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 1.414L7.414 9H15a1 1 0 110 2H7.414l2.293 2.293a1 1 0 010 1.414z" clip-rule="evenodd" />
                </svg>
                Volver al Dashboard
            </a>
        </div>

        <?php if(session('success')): ?>
            <div class="bg-green-100 text-green-800 p-3 rounded mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 text-red-800 p-3 rounded mb-4">
                <?php echo e($errors->first('msg')); ?>

            </div>
        <?php endif; ?>

        <div class="mb-4">
            <a href="<?php echo e(route('facturas.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded">
                Nueva Factura
            </a>
        </div>

        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
            <table class="w-full table-auto text-sm">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-4 py-2">ID</th>
                        <th class="px-4 py-2">Cliente</th>
                        <th class="px-4 py-2">Total</th>
                        <th class="px-4 py-2">Estado</th>
                        <th class="px-4 py-2">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b <?php echo e($factura->anulada ? 'bg-gray-100 text-gray-500' : ''); ?>">
                            <td class="px-4 py-2"><?php echo e($factura->id); ?></td>
                            <td class="px-4 py-2"><?php echo e($factura->cliente->nombre); ?></td>
                            <td class="px-4 py-2">$<?php echo e(number_format($factura->total, 2)); ?></td>
                            <td class="px-4 py-2">
                                <?php if($factura->anulada): ?>
                                    <span class="text-red-600 font-semibold">Anulada</span>
                                <?php else: ?>
                                    <span class="text-green-600 font-semibold">Válida</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-4 py-2 space-x-2">
                                <button onclick="openModal('verFactura-<?php echo e($factura->id); ?>')"
                                    class="text-blue-600 hover:underline">Ver</button>

                                <?php if(!$factura->anulada && ($factura->user_id == $usuarioId || $roles->contains('Administrador'))): ?>
                                    <button onclick="openModal('anularFactura-<?php echo e($factura->id); ?>')"
                                        class="text-red-600 hover:underline">Anular</button>
                                <?php endif; ?>
                                <a href="<?php echo e(route('facturas.pdf', $factura)); ?>" class="text-indigo-600 hover:underline">PDF</a>
                                <?php if($factura->cliente->email_verified_at): ?>
                                    <button onclick="openModal('notificarFactura-<?php echo e($factura->id); ?>')"
                                        class="text-yellow-600 hover:underline">Notificar</button>
                                <?php else: ?>
                                    <span class="text-gray-400 italic">Correo no verificado</span>
                                <?php endif; ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        
        <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Modal Ver Detalle -->
            <div id="verFactura-<?php echo e($factura->id); ?>"
                class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
                <div class="bg-white p-6 rounded shadow-md w-[600px] max-h-[80vh] overflow-y-auto">
                    <h3 class="text-lg font-bold mb-2">Factura #<?php echo e($factura->id); ?></h3>
                    <p><strong>Cliente:</strong> <?php echo e($factura->cliente->nombre); ?></p>
                    <p><strong>Total:</strong> $<?php echo e(number_format($factura->total, 2)); ?></p>
                    <p><strong>Estado:</strong> <?php echo e($factura->anulada ? 'Anulada' : 'Válida'); ?></p>
                    <?php if($factura->anulada): ?>
                        <p class="text-sm text-red-600 font-semibold mt-2">Esta factura fue anulada.</p>
                    <?php endif; ?>
                    <hr class="my-3">
                    <h4 class="font-semibold mb-2">Detalles:</h4>
                    <table class="w-full table-auto text-sm">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="px-2 py-1">Producto</th>
                                <th class="px-2 py-1">Cantidad</th>
                                <th class="px-2 py-1">P. Unitario</th>
                                <th class="px-2 py-1">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $factura->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-2 py-1"><?php echo e($detalle->producto->nombre); ?></td>
                                    <td class="px-2 py-1"><?php echo e($detalle->cantidad); ?></td>
                                    <td class="px-2 py-1">$<?php echo e(number_format($detalle->precio_unitario, 2)); ?></td>
                                    <td class="px-2 py-1">$<?php echo e(number_format($detalle->subtotal, 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="mt-4 text-right">
                        <button onclick="closeModal('verFactura-<?php echo e($factura->id); ?>')"
                            class="px-4 py-2 bg-gray-500 text-white rounded">Cerrar</button>
                    </div>
                </div>
            </div>

            <!-- Modal Anular -->
            <div id="anularFactura-<?php echo e($factura->id); ?>"
                class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
                <div class="bg-white p-6 rounded shadow-md w-96">
                    <h3 class="text-lg font-bold mb-4">¿Anular Factura #<?php echo e($factura->id); ?>?</h3>
                    <p>Esta acción restaurará el stock de los productos.</p>
                    <form method="POST" action="<?php echo e(route('facturas.anular', $factura)); ?>" class="mt-4">
                        <?php echo csrf_field(); ?>
                        <div class="flex justify-end">
                            <button type="button" onclick="closeModal('anularFactura-<?php echo e($factura->id); ?>')"
                                class="mr-2 px-4 py-2 bg-gray-300 rounded">Cancelar</button>
                            <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded">Anular</button>
                        </div>
                    </form>
                </div>
            </div>
            <!-- Modal Notificar -->
            <div id="notificarFactura-<?php echo e($factura->id); ?>"
                class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
                <div class="bg-white p-6 rounded shadow-md w-96">
                    <h3 class="text-lg font-bold mb-4">¿Enviar factura al cliente?</h3>
                    <p><strong>Factura:</strong> #<?php echo e($factura->id); ?></p>
                    <p><strong>Cliente:</strong> <?php echo e($factura->cliente->nombre); ?></p>
                    <p><strong>Correo:</strong> <?php echo e($factura->cliente->email); ?></p>

                    <form method="POST" action="<?php echo e(route('facturas.enviarPDF', $factura)); ?>" class="mt-4">
                        <?php echo csrf_field(); ?>
                        <div class="flex justify-end">
                            <button type="button" onclick="closeModal('notificarFactura-<?php echo e($factura->id); ?>')"
                                class="mr-2 px-4 py-2 bg-gray-300 rounded">Cancelar</button>
                            <button type="submit" class="bg-yellow-600 text-white px-4 py-2 rounded">Enviar</button>
                        </div>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- JS para abrir/cerrar modales -->
    <script>
        function openModal(id) {
            document.getElementById(id).classList.remove('hidden');
        }

        function closeModal(id) {
            document.getElementById(id).classList.add('hidden');
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\William\Documents\UniversidadNP\Desarollo de Software Seguro\Parcial 2\Proyecto 2\sistema-facturacion-segura\resources\views/facturas/index.blade.php ENDPATH**/ ?>